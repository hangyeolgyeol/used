package com.bitstudy.app.dao;

import com.bitstudy.app.domain.ProductDto;

public interface SellDAO {
    int proInsert(ProductDto DTO);
}
