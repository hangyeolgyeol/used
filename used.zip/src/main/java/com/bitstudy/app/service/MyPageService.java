package com.bitstudy.app.service;

public interface MyPageService {
    //    마이 페이지에서 회원정보 지우기
    int deleteCustomer(String cu_id);
}
